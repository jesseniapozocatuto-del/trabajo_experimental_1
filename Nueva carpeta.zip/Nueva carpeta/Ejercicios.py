# Ejercicio 1 · Quitar duplicados conservando el orden
# De ["Quito","Guayaquil","Quito","Cuenca","Guayaquil"], obtener una lista sin repetidos 
# respetando el orden de aparición.
ciudades = ["Quito", "Guayaquil", "Quito", "Cuenca", "Guayaquil"]

vistas = set()
unicas = []

for ciudad in ciudades:
    if ciudad not in vistas:
        vistas.add(ciudad)
        unicas.append(ciudad)

print(unicas)

# Ejercicio 2
# Armar {"Quito": 2, "Guayaquil": 2, "Cuenca": 1} y mostrar la ciudad más repetida.
ciudades = ["Quito", "Guayaquil", "Quito", "Cuenca", "Guayaquil"]

conteo = {}

for ciudad in ciudades:
    conteo[ciudad] = conteo.get(ciudad, 0) + 1

print(conteo)

ciudad_mas_repetida = max(conteo, key=conteo.get) #busca la clave que tiene el conteo mas grande

print("Ciudad más repetida:", ciudad_mas_repetida)

# Ejercicio 3 · Conjuntos en acción
# Con {"Ana","Luis","Sol","Marco"} y {"Luis","Marco","Ruth"}: ¿quiénes están en las dos?, ¿quiénes solo en la primera?, ¿cuántas personas distintas hay?
matematica = {"Ana", "Luis", "Sol"}
ingles = {"Luis", "Marco"}

ambas = matematica & ingles
solo_mate = matematica - ingles
total = len(matematica | ingles)

print("En las dos:", sorted(ambas))
print("Solo en matemática:", sorted(solo_mate))
print("Personas distintas:", total)

print("No comparten:", sorted(matematica ^ ingles))

# Ejercicio 4 · Propiedad calculada
# Agrega a Cliente la propiedad iniciales que devuelva "A.P." para “Ana Pérez”. No debe guardar nada: se calcula al leerla.
class Cliente:
    def __init__(self, nombre, apellido):
        self.nombre = nombre
        self.apellido = apellido

    @property
    def iniciales(self):
        return f"{self.nombre[0]}.{self.apellido[0]}.".upper()


cliente = Cliente("Ana", "Pérez")

print("\nEjercicio 4:")
print("Iniciales:", cliente.iniciales)

# Ejercicio 5 · Método estático
# Agrega a Cliente el método estático es_telefono_valido(texto): válido si está vacío o si son exactamente 10 dígitos. Úsalo en el setter de telefono.
class ClienteTelefono:

    @staticmethod
    def es_telefono_valido(texto):
        texto = str(texto).strip()

        if texto == "":
            return True

        return texto.isdigit() and len(texto) == 10


print("\nEjercicio 5:")

print(ClienteTelefono.es_telefono_valido("0991234567"))
print(ClienteTelefono.es_telefono_valido("12345"))
print(ClienteTelefono.es_telefono_valido(""))

# Ejercicio 6 · Método de clase (fábrica)
# Agrega Cliente.desde_texto("1, Ana, Pérez, ana@x.com") que devuelva un objeto Cliente. Debe funcionar también si mañana existe ClienteVIP(Cliente).
class ClienteTexto:

    def __init__(self, id_cliente, nombre, apellido, email):
        self.id = id_cliente
        self.nombre = nombre
        self.apellido = apellido
        self.email = email

    @classmethod
    def desde_texto(cls, linea):

        partes = [parte.strip() for parte in linea.split(",")]

        if len(partes) < 4:
            raise ValueError("Faltan datos")

        id_cliente = int(partes[0])
        nombre = partes[1]
        apellido = partes[2]
        email = partes[3]

        return cls(id_cliente, nombre, apellido, email)


cliente = ClienteTexto.desde_texto(
    "1, Ana, Pérez, ana@x.com"
)

print("\nEjercicio 6:")
print(cliente.id)
print(cliente.nombre)
print(cliente.apellido)
print(cliente.email)

# Ejercicio 7 · Atributo de clase
# Haz que Cliente lleve la cuenta de cuántos clientes se crearon y agrega el método de clase resumen() que devuelva "Se han creado N clientes". ¿Por qué resumen() no puede ser un método de instancia?
class ClienteContador:

    total_creados = 0

    def __init__(self, nombre):
        self.nombre = nombre
        ClienteContador.total_creados += 1

    @classmethod
    def resumen(cls):
        return f"Se han creado {cls.total_creados} clientes"


cliente1 = ClienteContador("Ana")
cliente2 = ClienteContador("Luis")

print("\nEjercicio 7:")
print(ClienteContador.resumen())

# Ejercicio 8 · Sobre el proyecto
# Agrega al Controlador el método de clase agrupar_por_ciudad() que devuelva {"Guayaquil": ["Ana", "Luis"], "Quito": ["Sol"]}, y muéstralo como opción 8 del menú.
class ClienteCiudad:

    def __init__(self, nombre, apellido, ciudad):
        self.nombre = nombre
        self.apellido = apellido
        self.ciudad = ciudad

    @property
    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"


class ClienteController:

    clientes = [
        ClienteCiudad("Ana", "Pérez", "Quito"),
        ClienteCiudad("Luis", "Gómez", "Guayaquil"),
        ClienteCiudad("María", "López", "Quito"),
        ClienteCiudad("Pedro", "Torres", "Cuenca"),
        ClienteCiudad("Sofía", "Mora", "")
    ]

    @classmethod
    def agrupar_por_ciudad(cls):

        agrupados = {}

        for cliente in cls.clientes:

            ciudad = cliente.ciudad or "Sin ciudad"

            if ciudad not in agrupados:
                agrupados[ciudad] = []

            agrupados[ciudad].append(cliente.nombre_completo)

        return agrupados


print("\nEjercicio 8:")

resultado = ClienteController.agrupar_por_ciudad()

for ciudad, nombres in resultado.items():
    print(ciudad, ":", ", ".join(nombres))
