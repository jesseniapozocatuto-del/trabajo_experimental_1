import json
import os


class GestorJSON:

    def __init__(self, archivo):
        self.archivo = archivo

    def leer(self):
        if not os.path.exists(self.archivo):
            return []

        try:
            with open(self.archivo, "r", encoding="utf-8") as archivo:
                return json.load(archivo)
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def guardar(self, datos):
        try:
            os.makedirs(os.path.dirname(self.archivo), exist_ok=True)

            with open(self.archivo, "w", encoding="utf-8") as archivo:
                json.dump(datos, archivo, ensure_ascii=False, indent=2)

            return True

        except OSError:
            return False