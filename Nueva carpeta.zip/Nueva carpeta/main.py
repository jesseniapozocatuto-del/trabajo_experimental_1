from views import EstudianteController


class MenuClientes:

    TITULO = "SISTEMA DE GESTIÓN DE CLIENTES"

    def __init__(self, controlador):
        self.controlador = controlador
        self.activo = True

    def pausa(self):
        input("\nPresione ENTER para continuar...")
    
    def crear(self):
        print("\n--- CREAR ESTUDIANTE ---")

        nombre = input("Nombre: ")
        apellido = input("Apellido: ")
        email = input("Email: ")
        carnet = input("Carnet: ")

        datos = {
            "nombre": nombre,
            "apellido": apellido,
            "email": email,
            "carnet": carnet
        }
        
        exito, mensaje = self.controlador.crear(datos)

        print(mensaje)
        self.pausa()

    def listar(self):
        print("\n--- ESTUDIANTES ---")

        estudiantes = self.controlador.listar()

        if not estudiantes:
            print("No hay registros.")
        else:
            for estudiante in estudiantes:
                print(estudiante)

        self.pausa()

    def buscar(self):
        termino = input("\nBuscar: ")

        resultados = self.controlador.buscar(termino)

        if not resultados:
            print("No se encontraron resultados.")
        else:
            for resultado in resultados:
                print(resultado)

        self.pausa()

    def ver_por_id(self):
        try:
            id_registro = int(input("ID: "))
        except ValueError:
            print("El ID debe ser un número.")
            self.pausa()
            return

        objeto = self.controlador.obtener(id_registro)

        if objeto:
            print(objeto)
        else:
            print("No existe ese registro.")

        self.pausa()

    def eliminar(self):
        try:
            id_registro = int(input("ID a eliminar: "))
        except ValueError:
            print("El ID debe ser un número.")
            self.pausa()
            return

        exito, mensaje = self.controlador.eliminar(id_registro)

        print(mensaje)
        self.pausa()

    def salir(self):
        self.activo = False
        print("\n¡Hasta luego!")

    def mostrar_menu(self):
        print("\n" + "=" * 50)
        print(self.TITULO)
        print("=" * 50)

        for numero, opcion in self.opciones.items():
            print(f"{numero}. {opcion[0]}")

    def ejecutar(self):
        while self.activo:
            self.mostrar_menu()

            opcion = input("\nSeleccione una opción: ")

            if opcion in self.opciones:
                self.opciones[opcion][1]()
            else:
                print("Opción no válida.")
                self.pausa()


class MenuEstudiantes(MenuClientes):

    TITULO = "SISTEMA DE GESTIÓN DE ESTUDIANTES"

    def __init__(self, controlador):
        super().__init__(controlador)

        self.opciones = {
            "1": ("Crear estudiante", self.crear),
            "2": ("Ver todos", self.listar),
            "3": ("Buscar", self.buscar),
            "4": ("Ver por id", self.ver_por_id),
            "5": ("Agregar nota", self.agregar_nota),
            "6": ("Ver promedio", self.ver_promedio),
            "7": ("Materias en común", self.materias_en_comun),
            "8": ("Eliminar", self.eliminar),
            "0": ("Salir", self.salir)
        }

    def agregar_nota(self):
        try:
            id_estudiante = int(input("ID del estudiante: "))
            materia = input("Materia: ")
            nota = float(input("Nota: "))

            exito, mensaje = self.controlador.agregar_nota(
                id_estudiante,
                materia,
                nota
            )

            print(mensaje)

        except ValueError:
            print("Datos inválidos.")

        self.pausa()

    def ver_promedio(self):
        try:
            id_estudiante = int(input("ID del estudiante: "))
        except ValueError:
            print("El ID debe ser un número.")
            self.pausa()
            return

        estudiante = self.controlador.obtener(id_estudiante)

        if estudiante:
            print(f"\nEstudiante: {estudiante.nombre_completo}")
            print(f"Promedio: {estudiante.promedio}")
            print(f"Estado: {estudiante.estado}")
        else:
            print("No existe ese estudiante.")

        self.pausa()

    def materias_en_comun(self):
        try:
            id_a = int(input("ID del primer estudiante: "))
            id_b = int(input("ID del segundo estudiante: "))
        except ValueError:
            print("Los IDs deben ser números.")
            self.pausa()
            return

        materias = self.controlador.materias_en_comun(id_a, id_b)

        if materias:
            print("\nMaterias en común:")
            for materia in materias:
                print(f"- {materia}")
        else:
            print("No tienen materias en común.")

        self.pausa()


# PROGRAMA PRINCIPAL

if __name__ == "__main__":
    menu = MenuEstudiantes(EstudianteController)
    menu.ejecutar()